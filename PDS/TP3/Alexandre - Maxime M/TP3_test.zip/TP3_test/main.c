#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "fonction.h"
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MIN_LENGTH_ARGV 3 //correspond aux "-n[0-9]+";
#define EXIT_FAILURE 1


int main(int args, char *argv[])
{
    int file=open(argv[2],O_RDONLY, 0644);
    if(file<0)
    {
        printf("file open error\n");
    }
    else
    {
        printf("requete : tail %s %s\n",argv[1],argv[2]);
        int lengthArgv=strlen(argv[1]);
        int test=0;
        int param=0;
        int i=2;
        if(lengthArgv>=MIN_LENGTH_ARGV)
        {
            if(argv[1][0]=='-')
            {
                param++;
                if((argv[1][1]=='n')||(argv[1][1]=='N')||(argv[1][1]==' '))
                {
                    param++;
                    while(argv[1][i]==' ')
                    {
                        param++;
                        i++;
                    }
                    while(i<lengthArgv)
                    {
                        if((argv[1][i]>=48)&&(argv[1][i]<=57))
                        {
                            test=1;
                        }
                        else
                        {
                            test=0;
                        }
                        i++;
                        //�quivaut � "^-[nN ]( )*[0-9]+$"
                    }
                    if(test)
                    {
                        printf("\n\n");
                        char *string=malloc((lengthArgv-param)*sizeof(char));
                        string=substr(argv[1],param);
                        int nline=atoi(string);
                        char *content_file=read_file(file);
                        show_n_line(content_file,nline,count_line(content_file));
                    }
                    else
                        exit(EXIT_FAILURE);
                }
                else
                    exit(EXIT_FAILURE);
            }
            else
                exit(EXIT_FAILURE);
        }
        else
            exit(EXIT_FAILURE);
    }
    return 0;
}
