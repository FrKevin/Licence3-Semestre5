#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include "fonction.c"

char* read_file(int file);
int count_line(char *content_file);
void show_n_line(char *content_file,int n, int nb_line);
char *substr(char* string, int length);

#endif // FONCTION_H_INCLUDED
