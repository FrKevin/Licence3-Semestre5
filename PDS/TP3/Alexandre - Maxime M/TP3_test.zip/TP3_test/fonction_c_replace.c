int count_line(int file)
{
    if (file < 0)
    {
        return NULL;
    }
    int res_lseek= lseek(file,0,SEEK_SET);
    printf("resultat de res_lseek: %d\nvaleur de la position courante: %d\n",res_lseek,tell(file));
    printf("code d'erreur: %d\n", errno);
    char courant;
    int res = read(file,&courant,1);
    int nb_line=1;
    int pos=0;
    if (res == 1)
    {
    //      printf("%c\n",courant);
        while(res == 1)
        {
            res = read(file,&courant,1);
            if(courant=='\n')
            {
                nb_line++;
            }
            pos++;
        }
    }
    else
    {
        return -1;
    }
    close(file);
    return nb_line;
}

char* read_line(int file)
{
    if (file < 0)
    {
        return NULL;
    }
    int i=0;
    char *line;
    char courant;
    line=(char *)malloc(sizeof(char*));
    int res = read(file,&courant,1);
    if (res == 1)
    {
        printf("lecture de block\n");
        while(res == 1)
        {
            line[i]=courant;
            i++;
            line = (char *)realloc(line,(1+i)*sizeof(char*));
            res = read(file,&courant,1);
        }
    }
    else
    {
        printf("Erreur de lecture du fichier\n");
    }
    line[i]='\0';
    close(file);
    return line;
}
void tail(char *pathname, int n)
{
    int file=open(pathname,O_RDONLY, 0644);
    if(file<0)
    {
        printf("erreur de lecture du fichier");
    }
    else
    {
        int nb_line= count_line(file);

        if(nb_line==-1)
        {
            printf("fichier vide\n");
        }
        else
        {
            printf("fichier non vide\n");
            int res_lseek= lseek(file,1,SEEK_SET);
            printf("resultat de res_lseek: %d\nvaleur de la position courante: %d\n",res_lseek,tell(file));
            printf("code d'erreur: %d\n", errno);
            char *content_file = read_line(file);
            if (content_file != NULL)
            {
                printf("%s\n",content_file);
                free(content_file);
            }
            else
            {
                printf("content_file is null");
            }
        }
    }
}
