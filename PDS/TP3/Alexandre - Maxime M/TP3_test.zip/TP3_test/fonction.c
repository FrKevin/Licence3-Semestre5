int count_line(char *content_file)
{
    int length= strlen(content_file);
    int i;
    int nb_line=0;
    for(i=0;i<length;i++)
    {
        if(content_file[i]=='\n')
        {
            nb_line++;
        }
    }
    return nb_line;
}

void show_n_line(char *content_file,int n, int nb_line)
{
    int length= strlen(content_file);
    int length_line=nb_line-n;
    int nb_line_string=0;
    int i=0;
    int length_i=0;
    int start=0, bigger_n=0;
    while((content_file[i]!='\0')&&(bigger_n==0))
    {
        if(n>=nb_line)
        {
            printf("%s",content_file);
            bigger_n=1;
        }
        else
        {
            if(content_file[i]=='\n')
            {
                nb_line_string++;
                if(nb_line_string==1)
                {
                    length_i=i;
                }
                if(nb_line_string>length_line)
                {
                    start=1;
                }
            }
            i++;
            if(start==1)
            {
                printf("%c",content_file[i]);
            }
        }
    }
}

char* read_file(int file)
{
    if (file < 0)
    {
        return NULL;
    }
    int i=0;
    char *line;
    char courant;
    line=(char *)malloc(sizeof(char*));
    int res = read(file,&courant,1);
    if (res == 1)
    {
        while(res == 1)
        {
            line[i]=courant;
            i++;
            line = (char *)realloc(line,(1+i)*sizeof(char*));
            res = read(file,&courant,1);
        }
    }
    else
    {
        printf("read open error\n");
    }
    line[i]='\0';
    close(file);
    return line;
}
char *substr(char* string, int length)
{
    int length2=strlen(string)-length;
    char *string2=malloc(length2*sizeof(char));
    int i=0;
    for(i;i<length2;i++)
    {
        string2[i]=string[i+length];
    }
    string2[i]='\0';
    return string2;
}
